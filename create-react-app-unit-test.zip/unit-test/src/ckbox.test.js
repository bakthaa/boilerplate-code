import React from "react";
import { render, screen } from "@testing-library/react";

const CkBox = (props) => {
  return <input type="checkbox" />;
};

test("sets the value to the upper version of the value", () => {
  const { container } = render(<CkBox />);
  const checkbox = container.firstChild;
  expect(checkbox.checked).not.toBe(true);
});
