export const sum = (a, b) => a + b;
